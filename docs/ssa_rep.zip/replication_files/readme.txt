1.) Installing arsimsens and pairsimsens.

Place arsimsens.ado and (optionally) arsimsens.hlp into the folder where personal ado files that start with "a" are stored. Typically, this will be something like "c:\ado\personal\a".
(Type "adopath" in Stata to find location of .ado files.)

Place pairsimsens.ado and (optionally) pairsimsens.hlp into the folder where personal ado files that start with "p" are stored.

2) Replication of tables presented in manuscript.

Data files (.dta) and scripts (.do) needed to replicate the tables presented in the manuscript are included here. The appropriate file names are given in the manuscript, before each set of tables is presented.

 